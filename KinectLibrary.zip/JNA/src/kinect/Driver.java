package kinect;
import java.awt.Graphics;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Driver extends JFrame implements WindowListener{
	boolean ready=false;
	Kinect leftKinect = new Kinect(0);
	Kinect rightKinect = new Kinect(1);
	public Driver(){
		addWindowListener(this);
		setSize(1400,600);
		add(new Canvas());

		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		System.out.println("Devices:"+Kinect.getSensorCount());
		System.out.println("LeftInit:"+leftKinect.initialize(Kinect.INITIALIZE_FLAGS.USES_DEPTH|Kinect.INITIALIZE_FLAGS.USES_COLOR));
		System.out.println("RightInit:"+rightKinect.initialize(Kinect.INITIALIZE_FLAGS.USES_COLOR));
		ready=true;
		System.out.println("leftAngle:"+leftKinect.getAngle());
		System.out.println("rightAngle:"+rightKinect.getAngle());
		leftKinect.setAngle(0);
		rightKinect.setAngle(0);
		setVisible(true);
	}
	public class Canvas extends JPanel{
		public void paintComponent(Graphics g){
			try {
				BufferedImage color=leftKinect.getInfraredImage(false);
				System.out.println("Depth:"+leftKinect.getDepthString(320, 240,false,false));
				g.drawImage(color,0,0,640,480,this);
				BufferedImage color2=rightKinect.getInfraredImage(true);
				g.drawImage(color2,640,0,640,480,this);
				repaint();
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(2);
			}
		}
	}
	public static void main(String[] args) {
		new Driver();
	}
	public void windowOpened(WindowEvent e) {}
	public void windowClosing(WindowEvent e) {}
	public void windowClosed(WindowEvent e) {
		leftKinect.shutdown();
		rightKinect.shutdown();
	}
	public void windowIconified(WindowEvent e) {}
	public void windowDeiconified(WindowEvent e) {}
	public void windowActivated(WindowEvent e) {}
	public void windowDeactivated(WindowEvent e) {}
}