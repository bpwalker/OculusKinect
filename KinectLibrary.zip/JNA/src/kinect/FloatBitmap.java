package kinect;
import java.awt.image.BufferedImage;


public class FloatBitmap {
	double[][] r,g,b;
	int numSamples=0;
	public FloatBitmap(int width,int height){
		r = new double[width][height];
		g = new double[width][height];
		b = new double[width][height];
	}
	public void addSample(BufferedImage i){
		int width=i.getWidth();
		int height=i.getHeight();
		if(width==r.length){
			if(height==r[0].length){
				
				for(int x=0; x<width; x++){
					for(int y=0; y<height; y++){
						//r[x][y]=((r[x][y]*numSamples)+Color.getRed(i.getRGB(x,y)))/(numSamples+1);
						//g[x][y]=((g[x][y]*numSamples)+Color.getGreen(i.getRGB(x,y)))/(numSamples+1);
						//b[x][y]=((b[x][y]*numSamples)+Color.getBlue(i.getRGB(x,y)))/(numSamples+1);
						r[x][y]=Math.max(r[x][y],Color.getRed(i.getRGB(x, y)));
						g[x][y]=Math.max(g[x][y],Color.getGreen(i.getRGB(x, y)));
						b[x][y]=Math.max(b[x][y],Color.getBlue(i.getRGB(x, y)));
						
					}
				}
			}
		}
		numSamples++;
	}
	public int getNumSamples(){
		return numSamples;
	}
	public BufferedImage getAverageImage(){
		int width=r.length;
		int height=r[0].length;
		BufferedImage output = new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);
		for(int x=0; x<width; x++){
			for(int y=0; y<height; y++){
				output.setRGB(x, y,Color.getRGB(255,(int)r[x][y],(int)g[x][y],(int)b[x][y]));
			}
		}
		return output;
	}
}
