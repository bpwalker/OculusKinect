package kinect;
import com.sun.jna.Library;
import com.sun.jna.Memory;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.ByteByReference;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.win32.StdCallLibrary;




public interface CustomKinectLibrary extends Library {
	CustomKinectLibrary INSTANCE = (CustomKinectLibrary)Native.loadLibrary(("ClassLibrary1.dll"),CustomKinectLibrary.class);
	
	boolean imageStreamGetNextImage(Pointer hStream,int millisToWait,Memory buffer,int imageSize);
	boolean getDepthData(Pointer sensor,Pointer hStream,int millisToWait,Memory buffer,int dataLength);
	boolean setAngle(Pointer sensor,int degrees);
	boolean initialize(Pointer sensor,int flags);
	Pointer imageStreamOpen(Pointer sensor,int imageType,int resolution,int frameFlags,int frameLimit);
	boolean shutdownKinect(Pointer sensor);
	int getAngle(Pointer sensor);
	boolean initSpeechSystem(Pointer sensor);
}
