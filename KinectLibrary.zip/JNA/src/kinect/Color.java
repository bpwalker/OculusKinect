package kinect;

public class Color {
	public static int getRGB(int alpha,int r,int g,int b){
		return (alpha&0xFF)<<24|(r&0xFF)<<16|(g&0xFF)<<8|(b&0xFF);
	}
	public static int getAlpha(int rgb){
		return (rgb>>24)&0xFF;
	}
	public static int getRed(int rgb){
		return (rgb>>16)&0xFF;
	}
	public static int getGreen(int rgb){
		return (rgb>>8)&0xFF;
	}
	public static int getBlue(int rgb){
		return rgb&0xFF;
	}
	public static int getDiff(int c1,int c2){
		int output=0;
		output+=Math.abs(Color.getRed(c1)-Color.getRed(c2));
		output+=Math.abs(Color.getGreen(c1)-Color.getGreen(c2));
		output+=Math.abs(Color.getBlue(c1)-Color.getBlue(c2));
		return output;
	}
}
