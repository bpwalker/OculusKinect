package kinect;


import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLong;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.LongByReference;
import com.sun.jna.ptr.PointerByReference;


public interface KinectLibrary extends Library {
	KinectLibrary INSTANCE = (KinectLibrary)Native.loadLibrary(("Kinect10"),KinectLibrary.class);

	//HRESULT NuiCreateSensorByIndex(int index,INuiSensor **ppNuiSensor);
	int NuiCreateSensorByIndex(int index,PointerByReference NuiSensor);
	
	//_Check_return_ HRESULT NUIAPI NuiGetSensorCount( _In_ int * pCount );
	int NuiGetSensorCount(IntByReference pCount);

}
