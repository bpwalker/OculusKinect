package kinect;

public interface SpeechCallback{
	public void wordFound(String s);
}
