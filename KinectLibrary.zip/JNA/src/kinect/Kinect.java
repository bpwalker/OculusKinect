package kinect;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.imageio.ImageIO;

import com.sun.jna.Memory;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.PointerByReference;


public class Kinect {
	public static final double MM_TO_INCH=0.0393701;

	SpeechCallback speechCallback = null;

	Pointer sensor;
	Pointer depthImageStream=Pointer.NULL;
	Pointer colorImageStream=Pointer.NULL;
	Pointer infraredImageStream=Pointer.NULL;

	BufferedImage depthImage = null;
	BufferedImage colorImage = null;
	BufferedImage infraredImage = null;

	Memory depthBuffer = null;
	Memory colorBuffer = null;
	Memory infraredBuffer = null;
	boolean initSuccess=false;

	char[] depthDataCache=null;

	public Kinect(int index){
		PointerByReference ref = new PointerByReference();
		KinectLibrary.INSTANCE.NuiCreateSensorByIndex(index,ref);
		sensor=ref.getValue();
		System.out.println("JavaSensor:"+sensor);
	}

	public class INITIALIZE_FLAGS{
		public static final int USES_AUDIO=0x10000000;
		public static final int USES_DEPTH_AND_PLAYER_INDEX=0x00000001;
		public static final int USES_COLOR=0x00000002;
		public static final int USES_SKELETON=0x00000008  ;
		public static final int USES_DEPTH=0x00000020;
		public static final int USES_HIGH_QUALITY_COLOR=0x00000040;// implies COLOR stream will be from uncompressed YUY2 @ 15fps
	}
	public enum IMAGE_TYPE{
		DEPTH_AND_PLAYER_INDEX,// USHORT
		COLOR,// RGB32 data
		COLOR_YUV,// YUY2 stream from camera h/w, but converted to RGB32 before user getting it.
		COLOR_RAW_YUV,// YUY2 stream from camera h/w.
		DEPTH,// USHORT
		COLOR_INFRARED,// USHORT
		COLOR_RAW_BAYER// 8-bit Bayer
	}
	public enum IMAGE_RESOLUTION{
		RES_80x60,
		RES_320x240,
		RES_640x480,
		RES_1280x960 //hi-res color only (15 fps)
	}
	//public class FrameTexture extends Structure{

	//}
	public class IMAGE_FRAME extends Structure{
		long timeStamp;
		int frameNumber;
		int imageType;//enum IMAGE_TYPE
		int res;//enum IMAGE_RESOLUTION

		protected List<String> getFieldOrder() {
			return Arrays.asList(new String[] { "xxx", "yyy", "zzz", "www" });
		}


	}
	//public static class ImageStream extends Pointer{}

	public static int getSensorCount(){
		IntByReference output = new IntByReference();
		KinectLibrary.INSTANCE.NuiGetSensorCount(output);
		return output.getValue();
	}
	public boolean initialize(int initializeFlags){
		System.out.println("Java initializing:"+sensor);
		if(sensor!=null){
			System.out.println("Sensor not null");
			if(CustomKinectLibrary.INSTANCE.initialize(sensor, initializeFlags)){
				initSuccess=true;
				System.out.println("Init Success");
			}else{
				System.out.println("Init Fail");
			}
		}else{
			System.out.println("Sensor is null");
		}
		return initSuccess;
	}
	public void shutdown(){
		initSuccess=false;
		if(sensor!=null){
			CustomKinectLibrary.INSTANCE.shutdownKinect(sensor);
		}
	}
	/**
	 * Range: -27 to 27
	 * This method blocks until the device has been moved to the specified location
	 * @param degrees
	 * @return
	 */
	public boolean setAngle(int degrees){
		if(sensor!=null){
			return CustomKinectLibrary.INSTANCE.setAngle(sensor, degrees);
		}else{
			return false;
		}
	}
	public int getAngle(){
		if(sensor!=null){
			return CustomKinectLibrary.INSTANCE.getAngle(sensor);
		}else{
			return 0;
		}
	}
	private Pointer openImageStream(IMAGE_TYPE imageType,IMAGE_RESOLUTION imageRes,int imageFrameFlags,int frameLimit){
		return CustomKinectLibrary.INSTANCE.imageStreamOpen(sensor, imageType.ordinal(), imageRes.ordinal(), imageFrameFlags, frameLimit);
	}
	public char[] getDepthData(){
		if(!initSuccess){
			return null;
		}
		if(depthImageStream==Pointer.NULL){
			depthImageStream=openImageStream(IMAGE_TYPE.DEPTH,IMAGE_RESOLUTION.RES_640x480,0,1);
			if(depthImageStream==Pointer.NULL){
				return null;
			}
		}
		Memory output = new Memory(640*480*2);
		CustomKinectLibrary.INSTANCE.getDepthData(sensor,depthImageStream,1000,output,640*480);
		depthDataCache=output.getCharArray(0,640*480);
		return depthDataCache;
	}
	public int getDepthMM(int x,int y,boolean refreshData,boolean mirror){
		if(depthDataCache==null||refreshData){
			getDepthData();
		}
		if(depthDataCache!=null){
			if(mirror){
				return depthDataCache[x+y*640]&0xFFF;
			}else{
				return depthDataCache[(640-1-x)+y*640]&0xFFF;
			}
		}
		return 0;
	}
	public int getAveragedDepthMM(int x,int y,boolean refreshData,boolean mirror){
		int totalFound=0;
		int sum=0;
		for(int x2=x-1; x2<=x+1; x2++){
			for(int y2=y-1; y2<=y+1; y2++){
				int temp=getDepthMM(x2,y2,refreshData,mirror);
				if(temp!=0){
					totalFound++;
					sum+=temp;
				}
			}
		}
		if(totalFound==0){
			return 0;
		}
		return sum/totalFound;
	}
	public double[] getReflectionVector(int x,int y,boolean refreshData,int pixels){
		final double H_DEGREES_PER_PIXEL=58.0/640.0;
		final double V_DEGREES_PER_PIXEL=48.0/480.0;
		int pixelWidth=pixels;
		boolean flip=false;
		double centerDepth=getAveragedDepthMM(x-pixelWidth/2,y-pixelWidth/2,refreshData,false);
		if(centerDepth==0){
			return new double[]{0,0,-1};
		}

		double rightDepth=getAveragedDepthMM(x+pixelWidth/2,y-pixelWidth/2,false,false);
		System.out.println("Depths:"+centerDepth+","+rightDepth);
		double angleX=pixelWidth*H_DEGREES_PER_PIXEL;
		double bounceAngleX=0;
		if(rightDepth!=0){
			double depthDistanceX=Math.sqrt(Math.pow(centerDepth,2)+Math.pow(rightDepth,2)-2*centerDepth*rightDepth*Math.cos(Math.toRadians(angleX)));
			System.out.println("DepthDistanceX:"+depthDistanceX +" mm");
			double hitAngleX=Math.toDegrees(Math.asin(rightDepth*Math.sin(Math.toRadians(angleX))/depthDistanceX));
			if(rightDepth>centerDepth){
				hitAngleX=180.0-hitAngleX;
				flip=true;
			}
			System.out.println("Hit AngleX:"+hitAngleX+" degrees");
			bounceAngleX=(hitAngleX-90)*2;//relative to hitAngle
			System.out.println("BounceAngleX:"+bounceAngleX);
		}else{
			return new double[]{0,0,-1};
		}

		double botDepth=getAveragedDepthMM(x,y+pixelWidth/2,false,false);
		double angleY=pixelWidth*V_DEGREES_PER_PIXEL;
		double bounceAngleY=0;
		if(botDepth!=0){
			double depthDistanceY=Math.sqrt(Math.pow(centerDepth,2)+Math.pow(botDepth,2)-2*centerDepth*botDepth*Math.cos(Math.toRadians(angleY)));
			System.out.println("DepthDistanceY:"+depthDistanceY +" mm");
			double hitAngleY=Math.toDegrees(Math.asin(botDepth*Math.sin(Math.toRadians(angleY))/depthDistanceY));
			if(botDepth>centerDepth){
				hitAngleY=180.0-hitAngleY;
			}
			System.out.println("Hit AngleY:"+hitAngleY+" degrees");
			bounceAngleY=(hitAngleY-90)*2;//relative to hitAngle
			System.out.println("BounceAngleY:"+bounceAngleY);
		}else{
			return new double[]{0,0,-1};
		}
		if(Math.abs(bounceAngleX)>90||Math.abs(bounceAngleY)>90){//flip
			return new double[]{-Math.tan(Math.toRadians(bounceAngleX)),Math.tan(Math.toRadians(bounceAngleY)),1};
		}else{
			return new double[]{Math.tan(Math.toRadians(bounceAngleX)),-Math.tan(Math.toRadians(bounceAngleY)),-1};
		}
		
	}
	public String getDepthString(int x,int y,boolean refreshData,boolean mirror){
		double mm=getDepthMM(x,y,refreshData,mirror);
		int inches=(int)(mm*MM_TO_INCH);
		if(inches<12||inches>(13*12)){
			return "----";
		}
		int feet=inches/12;
		inches=inches%12;
		return feet+"'"+inches+"\"";
	}
	public BufferedImage getDepthImage(boolean mirror,boolean refreshDepthData){
		if(!initSuccess){
			try{
				return ImageIO.read(new File("unavailable.png"));
			}catch (IOException e) {
				return null;
			}
		}

		int width=640;
		int height=480;
		if(depthImage==null){
			depthImage = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
		}
		if(depthDataCache==null||refreshDepthData){
			getDepthData();
		}

		if(depthDataCache!=null){
			//System.out.println("==============================");
			for(int x=0; x<width; x++){
				for(int y=0; y<height; y++){
					int val=depthDataCache[x+y*width];
					//System.out.println(val);
					val=val&0xFFF;
					val=val>>8;
				depthImage.setRGB(x, y,Color.getRGB(255,val,val,val));
				}
			}
			return depthImage;
		}
		return null;
	}
	/*
	public BufferedImage getDepthImage(boolean mirror){
		if(!initSuccess){
			try{
				return ImageIO.read(new File("unavailable.png"));
			}catch (IOException e) {
				return null;
			}
		}
		int width=640;
		int height=480;
		int bpp=2;//bytes/pixel
		int pitch=width*bpp;
		int dataSize=width*height*bpp;
		BufferedImage image=depthImage;
		Pointer imageStream=depthImageStream;
		Memory buffer = depthBuffer;

		if(image==null){
			image = new BufferedImage(640,480,BufferedImage.TYPE_INT_ARGB);
		}
		if(imageStream==Pointer.NULL){
			imageStream=openImageStream(IMAGE_TYPE.DEPTH,IMAGE_RESOLUTION.RES_640x480,0,1);
			if(imageStream==Pointer.NULL){
				return null;
			}
		}
		if(buffer==null){
			buffer = new Memory(dataSize);
		}
		boolean success=CustomKinectLibrary.INSTANCE.imageStreamGetNextImage(imageStream,1000,buffer,dataSize);
		if(!success){
			return null;
		}
		byte[] data=buffer.getByteArray(0,dataSize);

		if(mirror){
			for(int x=0; x<width; x++){
				for(int y=0; y<height; y++){
					int r=((data[x*bpp+1+y*pitch]&0xFF)<<8)+data[x*bpp+0+y*pitch]&0xFF;
					r=r&0x1FFF;
					image.setRGB(x, y,Color.getRGB(255,r,r,r));
				}
			}
		}else{
			for(int x=0; x<width; x++){
				for(int y=0; y<height; y++){
					int r=((data[x*bpp+y*pitch]&0xFF)<<8)+data[x*bpp+1+y*pitch]&0xFF;
					image.setRGB(width-1-x, y,Color.getRGB(255,r,r,r));
				}
			}
		}
		return image;
	}
	//*/
	public BufferedImage getColorImage(boolean mirror){//currently only 640x480x4 is supported
		//System.out.println("GetColorImage:"+sensor);
		if(!initSuccess){
			//System.out.println("Get fake image:"+sensor);
			try{
				return ImageIO.read(ClassLoader.getSystemResource("unavailable.png"));
			}catch (IOException e) {
				return null;
			}
		}
		//System.out.println("Get live image");
		int width=640;
		int height=480;
		int bpp=4;//bytes/pixel
		int pitch=width*bpp;
		int dataSize=width*height*bpp;
		BufferedImage image=colorImage;
		Pointer imageStream=colorImageStream;
		Memory buffer = colorBuffer;

		if(image==null){
			image = new BufferedImage(640,480,BufferedImage.TYPE_INT_ARGB);
		}
		if(imageStream==Pointer.NULL){
			imageStream=openImageStream(IMAGE_TYPE.COLOR,IMAGE_RESOLUTION.RES_640x480,0,1);
			if(imageStream==Pointer.NULL){
				return null;
			}
		}
		if(buffer==null){
			buffer = new Memory(dataSize);
		}
		boolean success=CustomKinectLibrary.INSTANCE.imageStreamGetNextImage(imageStream,1000,buffer,dataSize);
		if(!success){
			return null;
		}
		byte[] data=buffer.getByteArray(0,dataSize);

		if(mirror){
			for(int x=0; x<width; x++){
				for(int y=0; y<height; y++){
					int r=data[x*bpp+2+y*pitch]&0xFF;
					int gr=data[x*bpp+1+y*pitch]&0xFF;
					int b=data[x*bpp+0+y*pitch]&0xFF;
					image.setRGB(x, y,Color.getRGB(255,r,gr,b));
				}
			}
		}else{
			for(int x=0; x<width; x++){
				for(int y=0; y<height; y++){
					int r=data[x*bpp+2+y*pitch]&0xFF;
					int gr=data[x*bpp+1+y*pitch]&0xFF;
					int b=data[x*bpp+0+y*pitch]&0xFF;
					image.setRGB(width-1-x, y,Color.getRGB(255,r,gr,b));
				}
			}
		}
		return image;
	}
	public static void main(String[] args){
		double centerDepth=4;
		double rightDepth=5;

		double depthDistance=Math.sqrt(Math.pow(centerDepth,2)+Math.pow(rightDepth,2)-2*centerDepth*rightDepth*Math.cos(Math.toRadians(36.86)));
		System.out.println(Math.cos(Math.toRadians(36.86)));
		System.out.println(depthDistance);
	}
	public BufferedImage getInfraredImage(boolean mirror){//currently only 640x480x4 is supported
		//System.out.println("GetColorImage:"+sensor);
		if(!initSuccess){
			//System.out.println("Get fake image:"+sensor);
			try{
				return ImageIO.read(ClassLoader.getSystemResource("unavailable.png"));
			}catch (IOException e) {
				return null;
			}
		}
		//System.out.println("Get live image");
		int width=640;
		int height=480;
		int bpp=2;//bytes/pixel
		int pitch=width*bpp;
		int dataSize=width*height*bpp;
		BufferedImage image=infraredImage;
		Pointer imageStream=infraredImageStream;
		Memory buffer = infraredBuffer;

		if(image==null){
			image = new BufferedImage(640,480,BufferedImage.TYPE_INT_ARGB);
		}
		if(imageStream==Pointer.NULL){
			imageStream=openImageStream(IMAGE_TYPE.COLOR_INFRARED,IMAGE_RESOLUTION.RES_640x480,0,1);

			if(imageStream==Pointer.NULL){
				System.out.println("Null image stream");
				return null;
			}
		}
		if(buffer==null){
			buffer = new Memory(dataSize);
		}
		boolean success=CustomKinectLibrary.INSTANCE.imageStreamGetNextImage(imageStream,1000,buffer,dataSize);
		if(!success){
			return null;
		}
		byte[] data=buffer.getByteArray(0,dataSize);

		if(mirror){
			for(int x=0; x<width; x++){
				for(int y=0; y<height; y++){
					int r=data[x*bpp+1+y*pitch]&0xFF;
					image.setRGB(x, y,Color.getRGB(255,r,r,r));
				}
			}
		}else{
			for(int x=0; x<width; x++){
				for(int y=0; y<height; y++){
					int r=data[x*bpp+1+y*pitch]&0xFF;
					image.setRGB(width-1-x, y,Color.getRGB(255,r,r,r));
				}
			}
		}
		return image;
	}
	/*
	private boolean initSpeechSystem(){
		return CustomKinectLibrary.INSTANCE.initSpeechSystem(sensor);
	}
	public void setSpeechCallback(SpeechCallback c){
		if(speechCallback==null){
			if(initSpeechSystem()){
				speechCallback=c;
			}
		}else{
			speechCallback=c;
		}

	}
	 */
	//boolean imageStreamGetNextFrame(Pointer imageStream,int millisToWait){
	//	PointerByReference p = new PointerByReference();
	//	int ret=KinectLibrary.INSTANCE.NuiImageStreamGetNextFrame(imageStream,millisToWait, p);
	//	System.out.println("Ret value:"+ret);
	//	return true;
	//}
}
