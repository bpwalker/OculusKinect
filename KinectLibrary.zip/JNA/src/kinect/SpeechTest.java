package kinect;

public class SpeechTest implements SpeechCallback{
	public SpeechTest(){
		
	}
	/*
	public void run(){
		System.out.println("Started");
		Kinect k = new Kinect(0);
		k.initialize(Kinect.INITIALIZE_FLAGS.USES_DEPTH | Kinect.INITIALIZE_FLAGS.USES_AUDIO | Kinect.INITIALIZE_FLAGS.USES_COLOR);
		k.setSpeechCallback(this);
	}
	*/
	public static void main(String[] args){
		//new SpeechTest().run();
	}

	public void wordFound(String s) {
		// TODO Auto-generated method stub
		
	}
}
